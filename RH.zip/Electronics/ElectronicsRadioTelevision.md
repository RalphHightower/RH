---
layout: page
title: Electronics/Electronics / Radios 📻 / Television 📺 
permalink: /Electronics/
---

## Electronics 

| Electronics |
|---|
|   |

## Radios 📻 

| Radios 📻 | Date |
|---|---|
| [MyriadRF — Radios](https://myriadrf.org/status/mature/) |
| [IC-R8600 / Products / Icom America.](https://www.icomamerica.com/lineup/products/IC-R8600/)
| **[Listening to Ham Radio Operators Using the International Space Station - Hackster.io](https://www.hackster.io/news/listening-to-ham-radio-operators-using-the-international-space-station-e0a910c79ea1 )** | 2023 |

## Television 📺 

| Television 📺 | Date |
|---|---|
| [Range Xperts Patented Long Range VHF / UHF TV Antenna – Top Notch Antennas - Range Xperts TV Antennas](https://topnotchantennas.com/products/insane-gain-vhf-uhf-version ) |
| [How to Build an Android TV Box With a Raspberry Pi 4 - The Tech Edvocate](https://www.thetechedvocate.org/how-to-build-an-android-tv-box-with-a-raspberry-pi-4/ ) | June 26, 2023 |

## Electrical Grounding 

| Electrical Grounding — YouTube |
|---|
| [English: Part-1: Overcurrent & Earth Fault Protection // Over Current //...](https://youtube.com/watch?v=mG5xyUobvHo& ) |
| [English: Part-2: Overcurrent & Earth Fault Protection / PSM / TMS / IDMT...](https://youtube.com/watch?v=q-Ciz4wAaSk& )
| [English: Part-3: Overcurrent & Earth Fault Protection / Directional Over...](https://youtube.com/watch?v=T1yL034VMtY& ) |
| [English: Part-4: Application of Directional Over-Current Protection for ...](https://youtube.com/watch?v=fM77xA4t1AY& ) |

