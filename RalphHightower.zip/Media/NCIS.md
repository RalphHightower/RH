# Media/NCIS Franchise 

## NCIS Franchise 

### NCIS References 

| NCIS References |
|---|
| [All 12 TV Shows In The NCIS Shared Universe Explained](https://screenrant.com/ncis-shared-universe-explained/ ) |
| [JAG (1995) / ScreenRant](https://screenrant.com/tag/jag/ ) |
| [NCIS (2003) / ScreenRant](https://screenrant.com/tag/ncis-original-series/ ) |
| [NCIS: Los Angeles (2009) / ScreenRant](https://screenrant.com/tag/ncis-los-angeles/ ) |
| [NCIS: New Orleans (2014) / ScreenRant](https://screenrant.com/tag/ncis-new-orleans/ ) |
| [NCIS: Hawaii (2021) / ScreenRant](https://screenrant.com/tag/ncis-hawaii/ ) |
| [NCIS: Sydney (2023) / ScreenRant](https://screenrant.com/tag/ncis-sydney/ ) |
| [NCIS: Origins / ScreenRant](https://screenrant.com/tag/ncis-origins/ ) |

### NCIS News

| NCIS News | Date |
|---|---|
| [NCIS Spinoff Reuniting Cote de Pablo and Michael Weatherly Gets Its Title](https://www.cbr.com/ncis-michael-weatherly-cote-de-pablo-spinoff/ ) | May 7, 2024 |
| ['NCIS' Cote de Pablo, Michael Weatherly Spinoff Set at Paramount+](https://variety.com/2024/tv/news/ncis-spinoff-cote-de-pablo-michael-weatherly-paramount-plus-1235925895/ ) |
| [NCIS Season 21 Ducky Tribute Secretly Set Up Tony And Ziva’s Spinoff](https://screenrant.com/ncis-season-21-ducky-tribute-dinozzo-ziva-spinoff-setup/ ) |
| [Michael Weatherly and Cote de Pablo’s Tony and Ziva ‘NCIS’ spinoff is ordered at Paramount+ / March 2024 📺 - Training Hearts Academy](https://trainingheartsacademy.com/michael-weatherly-and-cote-de-pablos-tony-and-ziva-ncis-spinoff-is-ordered-at-paramount-march-2024/ ) |
| [Inside Michael Weatherly and Cote de Pablo's adorable friendship ahead of NCIS: Europe / HELLO!](https://www.hellomagazine.com/film/515590/ncis-stars-michael-weatherly-and-cote-de-pablo-sweet-friendship-explored/ ) |
| ["Dinozzo Is Coming": Michael Weatherly Teases New NCIS Location For Tony & Ziva Spinoff](https://screenrant.com/ncis-tony-dinozzo-ziva-spinoff-michael-weatherly-location-photo/ ) |

