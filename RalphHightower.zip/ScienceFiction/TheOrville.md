# Science Fiction/The Orville

## Reference Links

| The Orville References  |
|---|
| [The Orville / CBR](https://www.cbr.com/tag/the-orville/ )  |
|[The Orville (2017) / ScreenRant](https://screenrant.com/tag/the-orville/ ) |

## News

### The  Orville • CBR News

| The Orville — CBR News | Date |
|---|---|
| [Seth MacFarlane Keeps The Orville Season 4 Hopes Alive With Latest Update](https://www.cbr.com/seth-macfarlane-the-orville-season-4-hope-alive/ ) | JAN 22, 2024 |
| [The Orville: Why Halston Sage's Security Officer Alara Kitan Left the Ship](https://www.cbr.com/the-orville-why-halston-sage-alara-kitan-left/ ) | DEC 26, 2022 |
| [The Future Of Sci-Fi Television Depends On Season 4 Of The Orville](https://www.cbr.com/the-orville-season4-sci-fi-tv-future-hulu/ ) | AUG 9, 2022 |
| [The Orville Reveals the Truth About the Kaylon](https://www.cbr.com/orville-kaylon-truth-reveal-hulu/ ) | JUL 22, 2022 |
| [The Orville Is Better Than Ever - Except at Being Funny](https://www.cbr.com/the-orville-star-trek-fun-hulu/ ) | JUL 5, 2022 |
| [The Orville New Horizons Takes a Dark Turn With 'Electric Sheep'](https://www.cbr.com/orville-new-horizons-electric-sheep-dark-turn/ ) | JUN 28, 2022 |
| [The Orville Faces a Dark New Threat in Uncharted Space](https://www.cbr.com/the-orville-threat-uncharted-space-hulu/ ) | JUN 19, 2022 |
| [The Orville Masterminds Discuss Season 3’s Bigger Worldbuilding & Deeper Themes](https://www.cbr.com/the-orville-brannon-braga-david-goodman-jon-cassar-interview/ ) | JUN 7, 2022 |
| [The Orville's Adrianne Palicki & Penny Johnson Jerald Tease The ‘Shocking’ New Horizons](https://www.cbr.com/the-orville-adrianne-palicki-penny-johnson-jerald-interview/ ) | JUN 6, 2022 |
| [The Orville's Anne Winters & Jessica Szohr Unpack Their Season 3 Characters](https://www.cbr.com/the-orville-anne-winters-jessica-szohr-interview/ ) | JUN 6, 2022 |
| [The Orville: New Horizons Promises The Best Looking Season Yet](https://www.cbr.com/the-orville-new-horizons-disney-fox/ ) | JUN 2, 2022 |
| [Disney's Belief In The Orville: New Horizons Will Give Us The Best Looking Season Yet](https://www.cbr.com/the-orville-new-horizons-disney-fox/ ) | JUN 2, 2022 |
| [The Orville: New Horizons Trailer Includes Star Wars Easter Egg](https://www.cbr.com/the-orville-new-horizons-season-3-trailer-star-wars-easter-egg/ ) | MAY 14, 2022 |
| [The Orville Returning for Season 4 Is Looking 'Promising'](https://www.cbr.com/the-orville-season-4-return-promising/ ) | MAR 20, 2023 |

### The Orville • ScreenRant News

| The Orville — ScreenRant News | Date |
|---|---|
| [The Orville Season 4 Seemingly Confirmed By Seth MacFarlane After 2-Year Wait](https://screenrant.com/the-orville-season-4-confirmed-seth-macfarlane-response/ ) | APR 19, 2024 |
| [The Orville Would Overtake Star Trek In 1 Surprising Way If Season 4 Happens](https://screenrant.com/orville-season-4-overtake-star-trek-tos-cancel/ ) | JAN 29, 2024 |
| [The Orville Season 4: Will It Happen? Everything We Know](https://screenrant.com/orville-season-4-news-updates/ ) | NOV 30, 2023 |

### The Orville • Gizmodo News

| The Orville — Gizmodo News | Date  |
|---|---|
| [Seth MacFarlane Just Gave New Hope to Orville Fans Across the Galaxy](https://gizmodo.com/orville-season-4-seth-macfarlane-update-hulu-disney-1851143834 ) | January 5, 2024 |
| [10 Reasons Hulu Needs to Renew The Orville: New Horizons](https://gizmodo.com/the-orville-hulu-seth-macfarlane-season-4-renewal-1849360451 ) | August 4, 2022 |
| [The Orville Will Soon Stream on Both Hulu and Disney+](https://gizmodo.com/orville-seth-macfarlane-hulu-disney-san-diego-comiccon-1849323791 ) | July 24, 2022 |
| [Seth MacFarlane Interview: The Orville Versus Star Trek](https://gizmodo.com/seth-macfarlane-the-orville-season-3-hulu-star-trek-1848964522 ) | May 26, 2022 |
| [The Orville Season 3 Releases New Hulu Trailer](https://gizmodo.com/the-orville-season-3-new-trailer-hulu-seth-macfarlane-1848918041 ) | May 12, 2022 |
| [The Orville S3 Seth MacFarlane New Sneak Peek and Release Date](https://gizmodo.com/orville-season-3-delayed-new-clip-1848482122 ) | February 4, 2022 |
