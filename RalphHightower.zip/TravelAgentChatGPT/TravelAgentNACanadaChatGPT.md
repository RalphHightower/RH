# ChatGPT Travel Agent/North America/Canada 🇨🇦 
## [ChatGPT Travel Agent](https://chat.openai.com/)/North America 🌎 / Canada 🇨🇦 
#### Alberta 
#### British Columbia 
#### Ontario 
#### Prince Edward Island 
#### Quebec 
#### Newfound and Labrador 
#### Nova Scotia 
#### New Brunswick 
#### Northwest Territories 
#### Manitoba 
#### Saskatchewan 
#### Yukon 
