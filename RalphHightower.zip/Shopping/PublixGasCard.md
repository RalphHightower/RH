# Shopping/[Publix](https://www/publix.com/) Gas Card Coupon Sales Dates[^11]

## Gas Card Coupons[^12]

| Date Begins | Date Ends | Days Between |
|---|---|---|
| 2024-08-07 | 2024-08‐11 | 122 |
| 2024-04-17 | 2024-04-21 | 35 |
| 2024-03-13 | 2024-03-17 | 28 |
| 2024-02-14 | 2024-02-18 | 28 |
| 2024-01-17 | 2024-01-21 |  |

To keep track of the remaining balance on the gas card, I use a Post-It™ tag to write the remaining balance on the tag.

Using the $50 gas cards provides a layer of security from credit card skimmers hidden in gas pumps because the potential loss is limited to less than $50.

[^11]: Lexington, and Richland Counties, South Carolina. \$10 off \$50 gas card for \$50 groceries purchase, excluding lottery tickets, phone cards, beer, wine.<br />[Using a debit card, multiple cards may be purchased, one for each $50 purchase with the same exclusions.]
[^12]: I am using this page to determine a frequency pattern to this great sale. – *Ralph Hightower*
